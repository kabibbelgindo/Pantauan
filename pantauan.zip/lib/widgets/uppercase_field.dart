import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class UpperField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final IconData? icon;
  final TextInputType? keyboardType;
  final int maxLines;
  final bool readOnly;
  final VoidCallback? onTap;
  final String? Function(String?)? validator;
  final void Function(String)? onChanged;
  const UpperField({super.key, required this.controller, required this.label, this.icon, this.keyboardType, this.maxLines=1, this.readOnly=false, this.onTap, this.validator, this.onChanged});
  @override
  Widget build(BuildContext context) => TextFormField(
    controller: controller, textCapitalization: TextCapitalization.characters,
    keyboardType: keyboardType, maxLines: maxLines, readOnly: readOnly, onTap: onTap, validator: validator, onChanged: onChanged,
    inputFormatters: [TextInputFormatter.withFunction((o,n)=>TextEditingValue(text:n.text.toUpperCase(), selection:n.selection))],
    decoration: InputDecoration(labelText: label, prefixIcon: icon!=null?Icon(icon):null),
  );
}
