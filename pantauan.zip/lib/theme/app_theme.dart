import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF123B63);
  static const primaryDark = Color(0xFF0E3152);
  static const navSel = Color(0xFF1D5689);
  static const accent = Color(0xFF1F5F99);
  static const success = Color(0xFF146C60);
  static const danger = Color(0xFFA52A35);
  static const warning = Color(0xFFB45309);
  static const bg = Color(0xFFF4F7FB);
  static const surface = Color(0xFFFFFFFF);
  static const summaryBg = Color(0xFFE9F1F6);
  static const thead = Color(0xFFEEF3F8);
  static const textPrimary = Color(0xFF17365D);
  static const muted = Color(0xFF64748B);
  static const hint = Color(0xFF526477);
  static const border = Color(0xFFD5DEE8);
  static const locked = Color(0xFFE9EEF5);
}

class AppTheme {
  static ThemeData get light => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary, primary: AppColors.primary, surface: AppColors.surface),
    scaffoldBackgroundColor: AppColors.bg,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.primary, foregroundColor: Colors.white, elevation: 0, centerTitle: true,
      titleTextStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
      backgroundColor: AppColors.primary, foregroundColor: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    )),
    inputDecorationTheme: InputDecorationTheme(
      filled: true, fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.border)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.primary, width: 2)),
    ),
    cardTheme: CardTheme(color: AppColors.surface, elevation: 1, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5)),
    fontFamily: 'Roboto',
  );
}
