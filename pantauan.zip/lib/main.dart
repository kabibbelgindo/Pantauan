import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'services/config_service.dart';
import 'theme/app_theme.dart';
import 'screens/config_screen.dart';
import 'screens/login_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(statusBarColor: Color(0xFF123B63), statusBarIconBrightness: Brightness.light));
  runApp(const MaterialApp(title: 'Pantauan BR', debugShowCheckedModeBanner: false, home: Gate()));
}

class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}
class _GateState extends State<Gate> {
  bool loading=true, ok=false;
  @override
  void initState(){ super.initState(); ConfigService.isConfigured().then((v){ if(mounted) setState((){ok=v; loading=false;}); }); }
  @override
  Widget build(BuildContext context) {
    if(loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Theme(data: AppTheme.light, child: ok ? const LoginScreen() : const ConfigScreen());
  }
}
