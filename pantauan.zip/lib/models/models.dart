class StockLine {
  final int productId; final String code, name, size, location;
  final double qty, volume, purchasePrice;
  StockLine({required this.productId, required this.code, required this.name, required this.size, required this.location, required this.qty, this.volume=0, this.purchasePrice=0});
  double get value => qty * purchasePrice;
}

class Movement {
  final int? id; final String date, type, productCode, productName, size;
  final double qty, volume;
  final String? fromLocation, toLocation, location, destination, reference, note, seller;
  Movement({this.id, required this.date, required this.type, required this.productCode, required this.productName, this.size='', required this.qty, this.volume=0,
    this.fromLocation, this.toLocation, this.location, this.destination, this.reference, this.note, this.seller});
  factory Movement.fromMap(Map<String,dynamic> m)=>Movement(
    id:m['id']as int?, date:'${m['trx_date']??m['transfer_date']??''}', type:'${m['type']??'KELUAR'}',
    productCode:'${m['product_code']??m['code']??''}', productName:'${m['product_name']??m['name']??''}',
    size:'${m['trx_size']??m['size']??''}', qty:(m['qty']as num?)?.toDouble()??0, volume:(m['volume']as num?)?.toDouble()??0,
    fromLocation:m['from_location']?.toString(), toLocation:m['to_location']?.toString(),
    location:m['location']?.toString(), destination:m['destination']?.toString(),
    reference:m['number']?.toString(), note:m['note']?.toString(), seller:m['seller']?.toString(),
  );
}
