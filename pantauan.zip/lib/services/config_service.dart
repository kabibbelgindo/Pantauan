import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ConfigService {
  static const _cfg='app_configured', _mode='db_mode', _url='turso_url', _tok='turso_token', _co='company';
  static final _sec = FlutterSecureStorage(aOptions: const AndroidOptions(encryptedSharedPreferences: true));
  static Future<bool> isConfigured() async => (await SharedPreferences.getInstance()).getBool(_cfg)??false;
  static Future<void> save({required String mode, String? url, String? token, String company='PT BELGINDO RAYA'}) async {
    final p=await SharedPreferences.getInstance();
    await p.setBool(_cfg,true); await p.setString(_mode,mode); await p.setString(_co,company);
    if(url!=null&&url.isNotEmpty) await p.setString(_url,url.trim());
    if(token!=null&&token.isNotEmpty) await _sec.write(key:_tok,value:token.trim());
  }
  static Future<String> mode() async => (await SharedPreferences.getInstance()).getString(_mode)??'local';
  static Future<String?> url() async => (await SharedPreferences.getInstance()).getString(_url);
  static Future<String?> token() async => _sec.read(key:_tok);
  static Future<String> company() async => (await SharedPreferences.getInstance()).getString(_co)??'PT BELGINDO RAYA';
}
