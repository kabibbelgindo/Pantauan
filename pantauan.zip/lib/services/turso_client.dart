import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config_service.dart';

class TursoClient {
  static final i = TursoClient._();
  TursoClient._();

  Future<Map<String,String>?> _c() async {
    final u=await ConfigService.url(), t=await ConfigService.token();
    if(u==null||t==null||u.isEmpty||t.isEmpty) return null;
    var b=u.trim();
    if(b.startsWith('libsql://')) b=b.replaceFirst('libsql://','https://');
    if(!b.startsWith('http')) b='https://$b';
    return {'url': b.replaceAll(RegExp(r'/$'),''), 'token': t};
  }

  Future<List<Map<String,dynamic>>> q(String sql,[List<dynamic>? args]) async {
    final c=await _c();
    if(c==null) throw Exception('Turso belum dikonfigurasi');
    final body={
      'requests':[
        {'type':'execute','stmt':{'sql':sql, if(args!=null&&args.isNotEmpty) 'args': args.map((a){
          if(a==null) return {'type':'null'};
          if(a is int) return {'type':'integer','value':'$a'};
          if(a is double) return {'type':'float','value':a};
          return {'type':'text','value':'$a'};
        }).toList()}},
        {'type':'close'},
      ]
    };
    final res=await http.post(Uri.parse('${c['url']}/v2/pipeline'),
      headers:{'Authorization':'Bearer ${c['token']}','Content-Type':'application/json'},
      body: jsonEncode(body)).timeout(const Duration(seconds:30));
    if(res.statusCode>=400) throw Exception('Turso ${res.statusCode}: ${res.body}');
    final j=jsonDecode(res.body) as Map<String,dynamic>;
    final results=j['results'] as List???[];
    if(results.isEmpty) return [];
    final first=results.first as Map<String,dynamic>;
    if(first['type']=='error') throw Exception(first['error']?['message']??'query error');
    final result=(first['response'] as Map?)?['result'] as Map<String,dynamic>?;
    if(result==null) return [];
    final cols=(result['cols'] as List???[]).map((c)=>(c as Map)['name'] as String).toList();
    final rows=<Map<String,dynamic>>[];
    for(final r in (result['rows'] as List???[])){
      final cells=r as List; final m=<String,dynamic>{};
      for(var i=0;i<cols.length&&i<cells.length;i++){
        final cell=cells[i] as Map<String,dynamic>;
        final type=cell['type'] as String???'null'; var val=cell['value'];
        if(type=='null') val=null;
        else if(type=='integer') val=int.tryParse('$val')??val;
        else if(type=='float') val=double.tryParse('$val')??val;
        m[cols[i]]=val;
      }
      rows.add(m);
    }
    return rows;
  }

  Future<Map<String,dynamic>?> one(String sql,[List<dynamic>? args]) async {
    final r=await q(sql,args); return r.isEmpty?null:r.first;
  }
  Future<void> run(String sql,[List<dynamic>? args]) async { await q(sql,args); }
  Future<bool> ping() async { try{ await q('SELECT 1 AS ok'); return true;} catch(_){ return false;}}
}
