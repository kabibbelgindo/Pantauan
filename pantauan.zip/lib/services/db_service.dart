import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import '../models/models.dart';
import 'config_service.dart';
import 'turso_client.dart';

/// Read-only: UI tidak memanggil insert/update transaksi.
class DbService {
  static Database? _db;
  static Future<bool> get isTurso async => (await ConfigService.mode())=='turso';
  static Future<Database> get db async {
    if(_db!=null) return _db!;
    final dir=await getApplicationDocumentsDirectory();
    _db=await openDatabase(join(dir.path,'pantauan_br_merged.db'), version:1, onCreate:_create);
    return _db!;
  }

  static Future<void> _create(Database d, int v) async {
    await d.execute('''CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password_hash TEXT, full_name TEXT, role TEXT, active INTEGER DEFAULT 1, created_at TEXT)''');
    await d.execute('''CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, name TEXT, unit TEXT DEFAULT 'pcs', purchase_price REAL DEFAULT 0, min_stock REAL DEFAULT 0, active INTEGER DEFAULT 1)''');
    await d.execute('''CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, trx_date TEXT, number TEXT, product_id INTEGER, trx_size TEXT, qty REAL, volume REAL DEFAULT 0, location TEXT, destination TEXT, note TEXT, type TEXT, direction TEXT, seller TEXT, created_at TEXT)''');
    await d.execute('''CREATE TABLE location_transfers(id INTEGER PRIMARY KEY AUTOINCREMENT, transfer_date TEXT, product_id INTEGER, trx_size TEXT, qty REAL, volume REAL DEFAULT 0, from_location TEXT, to_location TEXT, note TEXT, created_at TEXT)''');
    final now=DateTime.now().toIso8601String();
    await d.insert('users',{'username':'bos','password_hash':'bos123','full_name':'Pimpinan','role':'viewer','active':1,'created_at':now});
    await d.insert('users',{'username':'admin','password_hash':'admin123','full_name':'Administrator','role':'viewer','active':1,'created_at':now});
    for(final p in [
      {'code':'KYU-001','name':'KAYU MERANTI','purchase_price':850000,'min_stock':20},
      {'code':'KYU-002','name':'KAYU JATI','purchase_price':2500000,'min_stock':10},
      {'code':'KYU-003','name':'KAYU SENGON','purchase_price':450000,'min_stock':50},
      {'code':'KYU-004','name':'KAYU KAMPER','purchase_price':1200000,'min_stock':15},
      {'code':'KYU-005','name':'KAYU MAHONI','purchase_price':1800000,'min_stock':12},
    ]) { await d.insert('products',p); }
    for(final r in [
      {'trx_date':'2026-10-01','product_id':1,'trx_size':'25×150×4000','qty':80.0,'volume':1.2,'location':'GUDANG A','type':'LOKAL','direction':'IN','seller':'PAK JOKO'},
      {'trx_date':'2026-10-05','product_id':2,'trx_size':'20×100×3000','qty':40.0,'volume':0.24,'location':'GUDANG A','type':'IMPOR','direction':'IN'},
      {'trx_date':'2026-10-08','product_id':3,'trx_size':'30×200×4000','qty':120.0,'volume':2.88,'location':'GUDANG B','type':'LOKAL','direction':'IN','seller':'BU SRI'},
      {'trx_date':'2026-10-15','product_id':5,'trx_size':'20×100×4000','qty':25.0,'volume':0.2,'location':'GUDANG B','type':'IMPOR','direction':'IN'},
      {'trx_date':'2026-10-20','product_id':1,'trx_size':'25×150×4000','qty':50.0,'volume':0.75,'location':'GUDANG A','type':'LOKAL','direction':'IN','seller':'PAK JOKO'},
    ]) { await d.insert('transactions',{...r,'created_at':now}); }
    for(final r in [
      {'trx_date':'2026-10-10','number':'OUT-001','product_id':1,'trx_size':'25×150×4000','qty':30.0,'volume':0.45,'location':'GUDANG A','destination':'PROYEK SEMARANG','type':'KELUAR','direction':'OUT'},
      {'trx_date':'2026-10-14','number':'OUT-002','product_id':3,'trx_size':'30×200×4000','qty':40.0,'volume':0.96,'location':'GUDANG B','destination':'TOKO JUWANA','type':'KELUAR','direction':'OUT'},
      {'trx_date':'2026-10-18','number':'OUT-003','product_id':2,'trx_size':'20×100×3000','qty':15.0,'volume':0.09,'location':'GUDANG A','destination':'PROYEK JEPARA','type':'KELUAR','direction':'OUT'},
      {'trx_date':'2026-10-22','number':'OUT-004','product_id':1,'trx_size':'25×150×4000','qty':25.0,'volume':0.375,'location':'GUDANG A','destination':'PROYEK SEMARANG','type':'KELUAR','direction':'OUT'},
    ]) { await d.insert('transactions',{...r,'created_at':now}); }
    for(final r in [
      {'transfer_date':'2026-10-11','product_id':1,'trx_size':'25×150×4000','qty':20.0,'volume':0.3,'from_location':'GUDANG A','to_location':'GUDANG B'},
      {'transfer_date':'2026-10-16','product_id':3,'trx_size':'30×200×4000','qty':15.0,'volume':0.36,'from_location':'GUDANG B','to_location':'GUDANG A'},
      {'transfer_date':'2026-10-21','product_id':5,'trx_size':'20×100×4000','qty':8.0,'volume':0.064,'from_location':'GUDANG B','to_location':'SHOWROOM'},
    ]) { await d.insert('location_transfers',{...r,'created_at':now}); }
  }

  static Future<Map<String,dynamic>?> login(String u,String p) async {
    final rows=await (await db).query('users',where:'username=? AND password_hash=? AND active=1',whereArgs:[u.trim().toLowerCase(),p],limit:1);
    return rows.isEmpty?null:rows.first;
  }

  static Future<List<StockLine>> stock({String? search}) async {
    final d=await db; final prods=await d.query('products',where:'active=1'); final out=<StockLine>[];
    for(final p in prods){
      final pid=p['id']as int;
      final ins=await d.rawQuery("SELECT trx_size size, location, SUM(qty) qty, SUM(volume) vol FROM transactions WHERE product_id=? AND direction='IN' GROUP BY trx_size,location",[pid]);
      final outs=await d.rawQuery("SELECT trx_size size, location, SUM(qty) qty, SUM(volume) vol FROM transactions WHERE product_id=? AND direction='OUT' GROUP BY trx_size,location",[pid]);
      final om=<String,Map<String,double>>{};
      for(final o in outs){ om['${o['size']}|${o['location']}']={'q':(o['qty']as num).toDouble(),'v':(o['vol']as num).toDouble()}; }
      for(final i in ins){
        final size='${i['size']}', loc='${i['location']}', key='$size|$loc';
        final qty=(i['qty']as num).toDouble()-(om[key]?['q']??0);
        if(qty.abs()<1e-9) continue;
        if(search!=null&&search.isNotEmpty){ final q=search.toUpperCase();
          if(!'${p['code']}'.toUpperCase().contains(q)&&!'${p['name']}'.toUpperCase().contains(q)&&!size.contains(q)&&!loc.contains(q)) continue; }
        out.add(StockLine(productId:pid, code:'${p['code']}', name:'${p['name']}', size:size, location:loc, qty:qty,
          volume:(i['vol']as num).toDouble()-(om[key]?['v']??0), purchasePrice:(p['purchase_price']as num?)?.toDouble()??0));
      }
    }
    out.sort((a,b)=>b.qty.compareTo(a.qty));
    return out;
  }

  static Future<Map<String,dynamic>> dashboard() async {
    final stocks=await stock();
    double tq=0, tv=0, tval=0; final byLoc=<String,double>{}; final bySeller=<String,double>{};
    for(final s in stocks){ tq+=s.qty; tv+=s.volume; tval+=s.value; byLoc[s.location]=(byLoc[s.location]??0)+s.qty; }
    final d=await db;
    final start=DateTime(DateTime.now().year,DateTime.now().month,1).toIso8601String().substring(0,10);
    final masuk=await d.rawQuery("SELECT COUNT(*) c, COALESCE(SUM(qty),0) q, COALESCE(SUM(volume),0) v FROM transactions WHERE direction='IN' AND trx_date>=?",[start]);
    final keluar=await d.rawQuery("SELECT COUNT(*) c, COALESCE(SUM(qty),0) q, COALESCE(SUM(volume),0) v FROM transactions WHERE direction='OUT' AND trx_date>=?",[start]);
    final mutasi=await d.rawQuery("SELECT COUNT(*) c, COALESCE(SUM(qty),0) q FROM location_transfers WHERE transfer_date>=?",[start]);
    final sellers=await d.rawQuery("SELECT seller, SUM(qty) q FROM transactions WHERE direction='IN' AND seller IS NOT NULL AND seller!='' AND trx_date>=? GROUP BY seller ORDER BY q DESC LIMIT 5",[start]);
    for(final s in sellers){ bySeller['${s['seller']}']=(s['q']as num).toDouble(); }
    // recent activity
    final recent=await d.rawQuery('''
      SELECT trx_date date, 'MASUK' kind, p.name name, t.qty, t.trx_size size FROM transactions t JOIN products p ON p.id=t.product_id WHERE direction='IN'
      UNION ALL
      SELECT trx_date, 'KELUAR', p.name, t.qty, t.trx_size FROM transactions t JOIN products p ON p.id=t.product_id WHERE direction='OUT'
      UNION ALL
      SELECT transfer_date, 'MUTASI', p.name, t.qty, t.trx_size FROM location_transfers t JOIN products p ON p.id=t.product_id
      ORDER BY date DESC LIMIT 10''');
    return {
      'lines':stocks.length,'total_qty':tq,'total_vol':tv,'total_value':tval,'by_loc':byLoc,'by_seller':bySeller,
      'masuk_c':masuk.first['c'],'masuk_q':masuk.first['q'],'masuk_v':masuk.first['v'],
      'keluar_c':keluar.first['c'],'keluar_q':keluar.first['q'],'keluar_v':keluar.first['v'],
      'mutasi_c':mutasi.first['c'],'mutasi_q':mutasi.first['q'],
      'top5':stocks.take(5).toList(),'recent':recent,
    };
  }

  static Future<List<Movement>> outgoing({int limit=100}) async {
    final rows=await (await db).rawQuery('''SELECT t.*, p.code product_code, p.name product_name, 'KELUAR' type
      FROM transactions t JOIN products p ON p.id=t.product_id WHERE t.direction='OUT' ORDER BY t.trx_date DESC LIMIT ?''',[limit]);
    return rows.map(Movement.fromMap).toList();
  }

  static Future<List<Movement>> mutations({int limit=100}) async {
    final rows=await (await db).rawQuery('''SELECT t.*, p.code product_code, p.name product_name, 'MUTASI' type, t.transfer_date trx_date
      FROM location_transfers t JOIN products p ON p.id=t.product_id ORDER BY t.transfer_date DESC LIMIT ?''',[limit]);
    return rows.map(Movement.fromMap).toList();
  }

  static Future<String> testTurso() async {
    if(!await isTurso) return 'Mode lokal.';
    return await TursoClient.i.ping()?'Terhubung Turso (pakai token READ-ONLY).':'Gagal Turso.';
  }
}
