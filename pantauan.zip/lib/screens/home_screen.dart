import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';
import '../services/db_service.dart';
import '../theme/app_theme.dart';
import 'riwayat_keluar_screen.dart';
import 'mutasi_screen.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  final Map<String,dynamic> user;
  const HomeScreen({super.key, required this.user});
  @override
  State<HomeScreen> createState() => _S();
}
class _S extends State<HomeScreen> {
  List<StockLine> stocks=[]; Map<String,dynamic>? sum; bool loading=true;
  final search=TextEditingController();
  final cur=NumberFormat.currency(locale:'id_ID', symbol:'Rp ', decimalDigits:0);

  @override
  void initState(){ super.initState(); _load(); }

  Future<void> _load() async {
    setState(()=>loading=true);
    final s=await DbService.stock(search:search.text);
    final d=await DbService.dashboard();
    if(mounted) setState((){stocks=s; sum=d; loading=false;});
  }

  void _nav(Widget w){ Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder:(_)=>w)); }

  @override
  Widget build(BuildContext context) {
    final uname=widget.user['full_name']??widget.user['username']??'';
    return Scaffold(
      appBar:AppBar(title:const Text('Stok + Ringkasan'), actions:[IconButton(icon:const Icon(Icons.refresh), onPressed:_load)]),
      drawer:Drawer(child:ListView(padding:EdgeInsets.zero, children:[
        DrawerHeader(decoration:const BoxDecoration(color:AppColors.primary), child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
          const Text('Pantauan BR', style:TextStyle(color:Colors.white,fontSize:20,fontWeight:FontWeight.bold)),
          Text('$uname', style:const TextStyle(color:Colors.white70)),
          const Spacer(),
          Container(padding:const EdgeInsets.symmetric(horizontal:8,vertical:2), decoration:BoxDecoration(color:Colors.white24,borderRadius:BorderRadius.circular(12)),
            child:const Text('READ-ONLY', style:TextStyle(color:Colors.white,fontSize:11,fontWeight:FontWeight.bold))),
          const SizedBox(height:4),
          const Text('PT Belgindo Raya — Grobogan', style:TextStyle(color:Colors.white60,fontSize:12)),
        ])),
        ListTile(leading:const Icon(Icons.inventory_2), title:const Text('Stok + Ringkasan'), selected:true, onTap:()=>Navigator.pop(context)),
        ListTile(leading:const Icon(Icons.outbox, color:AppColors.danger), title:const Text('Riwayat Barang Keluar'), onTap:()=>_nav(const RiwayatKeluarScreen())),
        ListTile(leading:const Icon(Icons.swap_horiz, color:AppColors.accent), title:const Text('Mutasi Barang'), onTap:()=>_nav(const MutasiScreen())),
        const Divider(),
        ListTile(leading:const Icon(Icons.logout, color:AppColors.danger), title:const Text('Keluar'),
          onTap:()=>Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder:(_)=>const LoginScreen()),(_)=>false)),
      ])),
      body:loading?const Center(child:CircularProgressIndicator()):RefreshIndicator(onRefresh:_load, child:CustomScrollView(slivers:[
        if(sum!=null) SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(12,12,12,4), child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
          const Text('Ringkasan Pimpinan', style:TextStyle(fontWeight:FontWeight.bold,fontSize:16,color:AppColors.textPrimary)),
          const SizedBox(height:8),
          Row(children:[_c(Icons.category,'Baris Stok','${sum!['lines']}',AppColors.primary), const SizedBox(width:8),
            _c(Icons.inventory,'Total Qty',NumberFormat.compact(locale:'id').format(sum!['total_qty']),AppColors.success)]),
          const SizedBox(height:8),
          Row(children:[_c(Icons.payments,'Nilai Stok',cur.format(sum!['total_value']),AppColors.accent), const SizedBox(width:8),
            _c(Icons.straighten,'Volume','${(sum!['total_vol']as num).toStringAsFixed(2)} m³',AppColors.primaryDark)]),
          const SizedBox(height:10),
          Container(width:double.infinity, padding:const EdgeInsets.all(12), decoration:BoxDecoration(color:AppColors.summaryBg,borderRadius:BorderRadius.circular(10)), child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
            const Text('Aktivitas Bulan Ini', style:TextStyle(fontWeight:FontWeight.w600)),
            const SizedBox(height:8),
            Row(mainAxisAlignment:MainAxisAlignment.spaceAround, children:[
              _m('Masuk','${sum!['masuk_c']}',AppColors.success), _m('Keluar','${sum!['keluar_c']}',AppColors.danger), _m('Mutasi','${sum!['mutasi_c']}',AppColors.accent),
            ]),
            const SizedBox(height:6),
            Text('Qty keluar: ${NumberFormat.compact(locale:'id').format(sum!['keluar_q'])}  •  Vol: ${(sum!['keluar_v']as num).toStringAsFixed(3)} m³',
              style:const TextStyle(fontSize:12,color:AppColors.muted)),
          ])),
          if((sum!['by_loc']as Map).isNotEmpty)...[
            const SizedBox(height:10),
            const Text('Stok per Lokasi', style:TextStyle(fontWeight:FontWeight.w600)),
            const SizedBox(height:6),
            Wrap(spacing:8, runSpacing:6, children:(sum!['by_loc']as Map<String,double>).entries.map((e)=>Chip(
              label:Text('${e.key}: ${e.value.toStringAsFixed(0)}', style:const TextStyle(fontSize:12)), backgroundColor:AppColors.thead)).toList()),
          ],
          if((sum!['by_seller']as Map).isNotEmpty)...[
            const SizedBox(height:10),
            const Text('Top Penjual (bulan ini)', style:TextStyle(fontWeight:FontWeight.w600)),
            const SizedBox(height:4),
            ...(sum!['by_seller']as Map<String,double>).entries.map((e)=>Padding(
              padding:const EdgeInsets.symmetric(vertical:2),
              child:Row(children:[Expanded(child:Text(e.key, style:const TextStyle(fontSize:13))), Text(e.value.toStringAsFixed(0), style:const TextStyle(fontWeight:FontWeight.bold,color:AppColors.success))]),
            )),
          ],
          if((sum!['top5']as List).isNotEmpty)...[
            const SizedBox(height:10),
            const Text('5 Stok Terbanyak', style:TextStyle(fontWeight:FontWeight.w600)),
            const SizedBox(height:4),
            ...(sum!['top5']as List<StockLine>).map((s)=>Padding(
              padding:const EdgeInsets.symmetric(vertical:2),
              child:Row(children:[Expanded(child:Text('${s.name} (${s.size})', style:const TextStyle(fontSize:13), overflow:TextOverflow.ellipsis)),
                Text(s.qty.toStringAsFixed(0), style:const TextStyle(fontWeight:FontWeight.bold,color:AppColors.success))]),
            )),
          ],
          if((sum!['recent']as List).isNotEmpty)...[
            const SizedBox(height:10),
            const Text('10 Aktivitas Terbaru', style:TextStyle(fontWeight:FontWeight.w600)),
            const SizedBox(height:4),
            ...(sum!['recent']as List).map((r){
              final kind='${r['kind']}'; final color=kind=='KELUAR'?AppColors.danger:kind=='MUTASI'?AppColors.accent:AppColors.success;
              return Padding(padding:const EdgeInsets.symmetric(vertical:2), child:Row(children:[
                Container(width:52, padding:const EdgeInsets.symmetric(vertical:2), decoration:BoxDecoration(color:color.withOpacity(0.12),borderRadius:BorderRadius.circular(4)),
                  child:Text(kind, textAlign:TextAlign.center, style:TextStyle(fontSize:10,fontWeight:FontWeight.bold,color:color))),
                const SizedBox(width:8),
                Expanded(child:Text('${r['name']} (${r['size']})', style:const TextStyle(fontSize:12), overflow:TextOverflow.ellipsis)),
                Text('${r['qty']}', style:const TextStyle(fontSize:12,fontWeight:FontWeight.w600)),
              ]));
            }),
          ],
        ]))),
        SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(12,12,12,4), child:TextField(
          controller:search, textCapitalization:TextCapitalization.characters,
          decoration:const InputDecoration(hintText:'CARI KODE / NAMA / UKURAN / LOKASI', prefixIcon:Icon(Icons.search)),
          onChanged:(_)=>_load(),
        ))),
        stocks.isEmpty?const SliverFillRemaining(child:Center(child:Text('Tidak ada data'))):
        SliverList(delegate:SliverChildBuilderDelegate((_,i){
          final s=stocks[i];
          return Card(child:ListTile(
            leading:CircleAvatar(backgroundColor:AppColors.primary.withOpacity(0.1), child:const Icon(Icons.forest,color:AppColors.primary,size:20)),
            title:Text(s.name, style:const TextStyle(fontWeight:FontWeight.w600)),
            subtitle:Text('${s.code} • ${s.size}\n${s.location}', style:const TextStyle(fontSize:12)),
            isThreeLine:true,
            trailing:Column(mainAxisAlignment:MainAxisAlignment.center, crossAxisAlignment:CrossAxisAlignment.end, children:[
              Text(s.qty.toStringAsFixed(s.qty==s.qty.roundToDouble()?0:1), style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16,color:AppColors.success)),
              Text(cur.format(s.value), style:const TextStyle(fontSize:11,color:AppColors.muted)),
            ]),
          ));
        }, childCount:stocks.length)),
      ])),
    );
  }

  Widget _c(IconData icon,String label,String value,Color color)=>Expanded(child:Container(
    padding:const EdgeInsets.all(12), decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(10),border:Border.all(color:AppColors.border)),
    child:Row(children:[
      Container(padding:const EdgeInsets.all(8), decoration:BoxDecoration(color:color.withOpacity(0.12),borderRadius:BorderRadius.circular(8)), child:Icon(icon,color:color,size:20)),
      const SizedBox(width:8),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
        Text(label, style:const TextStyle(fontSize:11,color:AppColors.muted)),
        Text(value, style:TextStyle(fontWeight:FontWeight.bold,fontSize:14,color:color), overflow:TextOverflow.ellipsis),
      ])),
    ]),
  ));
  Widget _m(String label,String value,Color c)=>Column(children:[
    Text(value, style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:c)),
    Text(label, style:const TextStyle(fontSize:11,color:AppColors.muted)),
  ]);
}
