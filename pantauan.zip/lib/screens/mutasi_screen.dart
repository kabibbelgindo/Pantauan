import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';
import '../services/db_service.dart';
import '../theme/app_theme.dart';

class MutasiScreen extends StatefulWidget {
  const MutasiScreen({super.key});
  @override
  State<MutasiScreen> createState() => _S();
}
class _S extends State<MutasiScreen> {
  List<Movement> list=[]; bool loading=true; String q='';
  @override
  void initState(){ super.initState(); _load(); }
  Future<void> _load() async { final d=await DbService.mutations(); if(mounted) setState((){list=d;loading=false;}); }
  List<Movement> get filtered {
    if(q.trim().isEmpty) return list;
    final s=q.toUpperCase();
    return list.where((m)=>m.productCode.contains(s)||m.productName.toUpperCase().contains(s)||(m.fromLocation??'').toUpperCase().contains(s)||(m.toLocation??'').toUpperCase().contains(s)).toList();
  }
  @override
  Widget build(BuildContext context) {
    final f=filtered; double tq=0; for(final m in f) tq+=m.qty;
    return Scaffold(
      appBar:AppBar(title:const Text('Mutasi Barang'), actions:[IconButton(icon:const Icon(Icons.refresh), onPressed:_load)]),
      body:Column(children:[
        Container(width:double.infinity, margin:const EdgeInsets.all(12), padding:const EdgeInsets.all(12),
          decoration:BoxDecoration(color:AppColors.summaryBg,borderRadius:BorderRadius.circular(8)),
          child:Text('Total: ${f.length} mutasi  •  Qty ${NumberFormat.compact(locale:'id').format(tq)}',
            style:const TextStyle(fontWeight:FontWeight.w600,color:AppColors.textPrimary))),
        Padding(padding:const EdgeInsets.symmetric(horizontal:12), child:TextField(
          textCapitalization:TextCapitalization.characters,
          decoration:const InputDecoration(hintText:'CARI KODE / NAMA / LOKASI', prefixIcon:Icon(Icons.search)),
          onChanged:(v)=>setState(()=>q=v),
        )),
        const SizedBox(height:8),
        Expanded(child:loading?const Center(child:CircularProgressIndicator()):f.isEmpty?const Center(child:Text('Tidak ada data')):
          RefreshIndicator(onRefresh:_load, child:ListView.builder(itemCount:f.length, itemBuilder:(_,i){
            final m=f[i];
            return Card(child:ListTile(
              leading:CircleAvatar(backgroundColor:AppColors.accent.withOpacity(0.12), child:const Icon(Icons.swap_horiz,color:AppColors.accent,size:20)),
              title:Text('${m.productName} (${m.size})', style:const TextStyle(fontWeight:FontWeight.w600)),
              subtitle:Text('${m.date}\n${m.fromLocation??'?'}  →  ${m.toLocation??'?'}', style:const TextStyle(fontSize:12)),
              isThreeLine:true,
              trailing:Text(m.qty.toStringAsFixed(m.qty==m.qty.roundToDouble()?0:1), style:const TextStyle(fontWeight:FontWeight.bold,color:AppColors.accent,fontSize:15)),
            ));
          }))),
      ]),
    );
  }
}
