import 'package:flutter/material.dart';
import '../services/config_service.dart';
import '../services/db_service.dart';
import '../theme/app_theme.dart';
import 'login_screen.dart';

class ConfigScreen extends StatefulWidget {
  const ConfigScreen({super.key});
  @override
  State<ConfigScreen> createState() => _S();
}
class _S extends State<ConfigScreen> {
  final f=GlobalKey<FormState>();
  String mode='local';
  final url=TextEditingController(), tok=TextEditingController(), co=TextEditingController(text:'PT BELGINDO RAYA');
  bool saving=false, obscure=true; String? msg;

  Future<void> _save() async {
    if(!f.currentState!.validate()) return;
    setState(()=>saving=true);
    await ConfigService.save(mode:mode, url:url.text, token:tok.text, company:co.text.trim().isEmpty?'PT BELGINDO RAYA':co.text.trim());
    if(mode=='turso') msg=await DbService.testTurso();
    if(!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder:(_)=>Theme(data:AppTheme.light, child:const LoginScreen())));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24), child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:420), child:Form(key:f, child:Column(crossAxisAlignment:CrossAxisAlignment.stretch, children:[
      const Icon(Icons.analytics_outlined, size:52, color:AppColors.primary),
      const SizedBox(height:10),
      const Text('Konfigurasi — Pantauan BR', textAlign:TextAlign.center, style:TextStyle(fontSize:20, fontWeight:FontWeight.bold, color:AppColors.textPrimary)),
      const Text('Read-Only • PT Belgindo Raya — Grobogan', textAlign:TextAlign.center, style:TextStyle(color:AppColors.muted, fontSize:13)),
      const SizedBox(height:18),
      SegmentedButton<String>(segments:const [
        ButtonSegment(value:'local', label:Text('Lokal'), icon:Icon(Icons.phone_android,size:16)),
        ButtonSegment(value:'turso', label:Text('Turso'), icon:Icon(Icons.cloud,size:16)),
      ], selected:{mode}, onSelectionChanged:(s)=>setState(()=>mode=s.first)),
      const SizedBox(height:14),
      TextFormField(controller:co, decoration:const InputDecoration(labelText:'Nama Perusahaan', prefixIcon:Icon(Icons.business))),
      if(mode=='turso')...[
        const SizedBox(height:12),
        TextFormField(controller:url, decoration:const InputDecoration(labelText:'Turso URL', prefixIcon:Icon(Icons.link)), validator:(v)=>mode=='turso'&&(v==null||v.isEmpty)?'Wajib':null),
        const SizedBox(height:12),
        TextFormField(controller:tok, obscureText:obscure, decoration:InputDecoration(labelText:'Auth Token (READ-ONLY disarankan)', prefixIcon:const Icon(Icons.vpn_key),
          suffixIcon:IconButton(icon:Icon(obscure?Icons.visibility:Icons.visibility_off), onPressed:()=>setState(()=>obscure=!obscure))),
          validator:(v)=>mode=='turso'&&(v==null||v.isEmpty)?'Wajib':null),
        if(msg!=null) Padding(padding:const EdgeInsets.only(top:8), child:Text(msg!, style:TextStyle(color:msg!.contains('Terhubung')?AppColors.success:AppColors.danger, fontSize:13))),
      ],
      const SizedBox(height:22),
      ElevatedButton(onPressed:saving?null:_save, child:Text(saving?'...':'Simpan & Lanjut')),
    ]))))));
  }
}
