import 'package:flutter/material.dart';
import '../services/db_service.dart';
import '../theme/app_theme.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _S();
}
class _S extends State<LoginScreen> {
  final f=GlobalKey<FormState>();
  final u=TextEditingController(), p=TextEditingController();
  bool loading=false, obscure=true; String? err;

  Future<void> _go() async {
    if(!f.currentState!.validate()) return;
    setState((){loading=true;err=null;});
    try{
      final user=await DbService.login(u.text,p.text);
      if(user==null){setState(()=>err='Username/password salah');return;}
      if(!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder:(_)=>HomeScreen(user:user)));
    }catch(e){setState(()=>err='$e');}
    finally{if(mounted)setState(()=>loading=false);}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24), child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:380), child:Form(key:f, child:Column(children:[
      Container(width:84,height:84,decoration:BoxDecoration(color:AppColors.primary,borderRadius:BorderRadius.circular(18)),
        child:const Icon(Icons.analytics_outlined,size:44,color:Colors.white)),
      const SizedBox(height:14),
      const Text('Pantauan BR', style:TextStyle(fontSize:24,fontWeight:FontWeight.bold,color:AppColors.primary)),
      const Text('Monitoring Read-Only\nPT Belgindo Raya — Grobogan', textAlign:TextAlign.center, style:TextStyle(color:AppColors.muted,fontSize:13)),
      const SizedBox(height:8),
      Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:4), decoration:BoxDecoration(color:AppColors.warning.withOpacity(0.15),borderRadius:BorderRadius.circular(20)),
        child:const Text('MODE READ-ONLY', style:TextStyle(fontSize:11,fontWeight:FontWeight.bold,color:AppColors.warning))),
      const SizedBox(height:22),
      TextFormField(controller:u, decoration:const InputDecoration(labelText:'Username',prefixIcon:Icon(Icons.person_outline)), validator:(v)=>v==null||v.isEmpty?'Wajib':null),
      const SizedBox(height:12),
      TextFormField(controller:p, obscureText:obscure, onFieldSubmitted:(_)=>_go(),
        decoration:InputDecoration(labelText:'Password',prefixIcon:const Icon(Icons.lock_outline),
          suffixIcon:IconButton(icon:Icon(obscure?Icons.visibility:Icons.visibility_off), onPressed:()=>setState(()=>obscure=!obscure))),
        validator:(v)=>v==null||v.isEmpty?'Wajib':null),
      if(err!=null) Padding(padding:const EdgeInsets.only(top:8), child:Text(err!,style:const TextStyle(color:AppColors.danger))),
      const SizedBox(height:18),
      SizedBox(width:double.infinity, child:ElevatedButton(onPressed:loading?null:_go, child:Text(loading?'...':'Masuk'))),
      const SizedBox(height:12),
      const Text('bos / bos123   •   admin / admin123', style:TextStyle(fontSize:12,color:AppColors.muted)),
    ]))))));
  }
}
