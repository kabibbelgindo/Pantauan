import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';
import '../services/db_service.dart';
import '../theme/app_theme.dart';

class RiwayatKeluarScreen extends StatefulWidget {
  const RiwayatKeluarScreen({super.key});
  @override
  State<RiwayatKeluarScreen> createState() => _S();
}
class _S extends State<RiwayatKeluarScreen> {
  List<Movement> list=[]; bool loading=true; String q='';
  @override
  void initState(){ super.initState(); _load(); }
  Future<void> _load() async { final d=await DbService.outgoing(); if(mounted) setState((){list=d;loading=false;}); }
  List<Movement> get filtered {
    if(q.trim().isEmpty) return list;
    final s=q.toUpperCase();
    return list.where((m)=>m.productCode.contains(s)||m.productName.toUpperCase().contains(s)||(m.destination??'').toUpperCase().contains(s)||(m.reference??'').toUpperCase().contains(s)).toList();
  }
  @override
  Widget build(BuildContext context) {
    final f=filtered; double tq=0,tv=0; for(final m in f){tq+=m.qty;tv+=m.volume;}
    return Scaffold(
      appBar:AppBar(title:const Text('Riwayat Barang Keluar'), actions:[IconButton(icon:const Icon(Icons.refresh), onPressed:_load)]),
      body:Column(children:[
        Container(width:double.infinity, margin:const EdgeInsets.all(12), padding:const EdgeInsets.all(12),
          decoration:BoxDecoration(color:AppColors.summaryBg,borderRadius:BorderRadius.circular(8)),
          child:Text('Total: ${f.length} trx  •  Qty ${NumberFormat.compact(locale:'id').format(tq)}  •  Vol ${tv.toStringAsFixed(4)} m³',
            style:const TextStyle(fontWeight:FontWeight.w600,color:AppColors.textPrimary))),
        Padding(padding:const EdgeInsets.symmetric(horizontal:12), child:TextField(
          textCapitalization:TextCapitalization.characters,
          decoration:const InputDecoration(hintText:'CARI KODE / NAMA / TUJUAN', prefixIcon:Icon(Icons.search)),
          onChanged:(v)=>setState(()=>q=v),
        )),
        const SizedBox(height:8),
        Expanded(child:loading?const Center(child:CircularProgressIndicator()):f.isEmpty?const Center(child:Text('Tidak ada data')):
          RefreshIndicator(onRefresh:_load, child:ListView.builder(itemCount:f.length, itemBuilder:(_,i){
            final m=f[i];
            return Card(child:ListTile(
              leading:CircleAvatar(backgroundColor:AppColors.danger.withOpacity(0.12), child:const Icon(Icons.outbox,color:AppColors.danger,size:20)),
              title:Text('${m.productName} (${m.size})', style:const TextStyle(fontWeight:FontWeight.w600)),
              subtitle:Text('${m.date} • ${m.reference??'-'}\n${m.location??''} → ${m.destination??''}', style:const TextStyle(fontSize:12)),
              isThreeLine:true,
              trailing:Text('-${m.qty.toStringAsFixed(m.qty==m.qty.roundToDouble()?0:1)}', style:const TextStyle(fontWeight:FontWeight.bold,color:AppColors.danger,fontSize:15)),
              onTap:()=>showModalBottomSheet(context:context, builder:(_)=>Padding(padding:const EdgeInsets.all(20), child:Column(mainAxisSize:MainAxisSize.min, crossAxisAlignment:CrossAxisAlignment.start, children:[
                const Text('Detail Keluar', style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
                const SizedBox(height:10),
                Text('Tanggal: ${m.date}'), Text('No: ${m.reference??'-'}'), Text('Barang: ${m.productCode} — ${m.productName}'),
                Text('Ukuran: ${m.size}'), Text('Qty: ${m.qty}'), Text('Vol: ${m.volume.toStringAsFixed(4)} m³'),
                Text('Dari: ${m.location??'-'}'), Text('Tujuan: ${m.destination??'-'}'),
                const SizedBox(height:8),
                const Text('Read-only — tidak dapat diubah', style:TextStyle(fontSize:12,color:AppColors.muted,fontStyle:FontStyle.italic)),
              ]))),
            ));
          }))),
      ]),
    );
  }
}
